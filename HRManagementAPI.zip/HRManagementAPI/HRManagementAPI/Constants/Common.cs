﻿namespace HRManagementAPI.Constants
{
    /// <summary>
    /// Common constants
    /// </summary>
    public class Common
    {
        public const string IdNotEmpty = "Id cannot be empty.";
        public const string IdNotExist = "Id doesn`t exist, please try different.";
        public const string NoEmpFound = "No Employee found for id: {0}";
        public const string AddEmpSuccessful = "Employee with Id: '{0}' added successfully.";
        public const string UpdateEmpSuccessful = "Employee with Id: '{0}' updated successfully.";
        public const string DeleteEmpSuccessful = "Employee with Id: '{0}' deleted successfully.";
        public const string NotSupportedEmpType = "Please add correct Employee type, supported emp types are: '{0}'";
        public const string IdExist = "Id: '{0}' exist, please use different id for insert.";

        public const string ExceptionMsg = "Exception occurred message: {0}";
    }
}
