﻿using HRManagementAPI.Constants;
using HRManagementAPI.Enums;
using HRManagementAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace HRManagementAPI.Controllers
{
    [Route("employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        EmployeeData employeeData;

        public EmployeeController(EmployeeData employeeData)
        {
            this.employeeData = employeeData;
        }

        /// <summary>
        /// Get all employee info
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(employeeData.EmployeeModels);
        }

        /// <summary>
        /// Get employee data by id
        /// </summary>
        /// <param name="id">id of the employee</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            // Input Validations
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest(Common.IdNotEmpty);
            }
            if (!employeeData.EmployeeModels.Any(x => x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)))
            {
                return BadRequest(Common.IdNotExist);
            }

            if (employeeData.EmployeeModels.Any(x => x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)))
            {
                return Ok(employeeData.EmployeeModels.FirstOrDefault(x => x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)));
            }
            else
            {
                return NotFound(string.Format(Common.NoEmpFound));
            }
        }

        /// <summary>
        /// Add new employee
        /// </summary>
        /// <param name="value"></param>
        [HttpPost]
        public IActionResult Post([FromBody] EmployeeModel employeeModel)
        {
            try
            {
                // Input Validations
                if (!(employeeModel.Type.Equals(EmployeeType.Permanent.ToString(), StringComparison.InvariantCultureIgnoreCase)
                || employeeModel.Type.Equals(EmployeeType.Temporary.ToString(), StringComparison.InvariantCultureIgnoreCase)))
                {
                    return BadRequest(string.Format(Common.NotSupportedEmpType, $"{EmployeeType.Permanent.ToString()}, {EmployeeType.Temporary.ToString()}"));
                }
                if (employeeData.EmployeeModels.Any(x => x.Id.Equals(employeeModel.Id, StringComparison.InvariantCultureIgnoreCase)))
                {
                    return BadRequest(string.Format(Common.IdExist, employeeModel.Id));
                }

                // Update Employee Salary
                UpdateSalary(employeeModel);

                employeeData.EmployeeModels.Add(employeeModel);
                return Ok(string.Format(Common.AddEmpSuccessful, employeeModel.Id));
            }
            catch (Exception ex)
            {
                return BadRequest(string.Format(Common.ExceptionMsg, ex.Message));
            }
        }

        /// <summary>
        /// Update Employee
        /// </summary>
        /// <param name="id">id of the employee</param>
        /// <param name="employeeModel"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody] EmployeeModel employeeModel)
        {
            try
            {
                // Input Validations
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest(Common.IdNotEmpty);
                }
                if (!employeeData.EmployeeModels.Any(x => x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)))
                {
                    return BadRequest(Common.IdNotExist);
                }
                if (!(employeeModel.Type.Equals(EmployeeType.Permanent.ToString(), StringComparison.InvariantCultureIgnoreCase)
                || employeeModel.Type.Equals(EmployeeType.Temporary.ToString(), StringComparison.InvariantCultureIgnoreCase)))
                {
                    return BadRequest(string.Format(Common.NotSupportedEmpType, $"{EmployeeType.Permanent.ToString()}, {EmployeeType.Temporary.ToString()}"));
                }

                employeeData.EmployeeModels.ForEach(x =>
                {
                    if (x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase))
                    {
                        x.Name = employeeModel.Name;
                        x.Age = employeeModel.Age;
                        x.BasicPay = employeeModel.BasicPay;
                        x.Designation = employeeModel.Designation;
                        x.Type = employeeModel.Type;
                    }
                });

                return Ok(string.Format(Common.UpdateEmpSuccessful, id));
            }
            catch (Exception ex)
            {
                return BadRequest(string.Format(Common.ExceptionMsg, ex.Message));
            }
        }

        /// <summary>
        /// Delete employee
        /// </summary>
        /// <param name="id">id of the employee</param>
        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                // Input Validations
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest(Common.IdNotEmpty);
                }
                if (!employeeData.EmployeeModels.Any(x => x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)))
                {
                    return BadRequest(Common.IdNotExist);
                }

                employeeData.EmployeeModels = employeeData.EmployeeModels.Where(x => !x.Id.Equals(id, StringComparison.InvariantCultureIgnoreCase)).ToList();

                return Ok(string.Format(Common.DeleteEmpSuccessful, id));
            }
            catch (Exception ex)
            {
                return BadRequest(string.Format(Common.ExceptionMsg, ex.Message));
            }
        }

        #region Private Methods
        private static void UpdateSalary(EmployeeModel employeeModel)
        {
            if (employeeModel.Type.Equals(EmployeeType.Permanent.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                employeeModel.Salary = 2.0 * employeeModel.BasicPay;
            }
            if (employeeModel.Type.Equals(EmployeeType.Temporary.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                employeeModel.Salary = 1.5 * employeeModel.BasicPay;
            }
        }

        #endregion
    }
}
