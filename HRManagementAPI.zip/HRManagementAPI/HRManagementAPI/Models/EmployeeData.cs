﻿using System.Collections.Generic;

namespace HRManagementAPI.Models
{
    /// <summary>
    /// EmployeeData
    /// </summary>
    public class EmployeeData
    {
        public EmployeeData()
        {
            EmployeeModels = new List<EmployeeModel>();
        }

        /// <summary>
        /// EmployeeModels
        /// </summary>
        public List<EmployeeModel> EmployeeModels { get; set; }
    }
}
