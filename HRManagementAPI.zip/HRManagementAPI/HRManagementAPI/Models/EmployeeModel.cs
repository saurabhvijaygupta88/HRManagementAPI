﻿namespace HRManagementAPI.Models
{
    /// <summary>
    /// Employee Model
    /// </summary>
    public class EmployeeModel
    {
        /// <summary>
        /// Id of the employedd
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Name of the employedd
        /// </summary>
        public string  Name { get; set; }

        /// <summary>
        /// Age of the employedd
        /// </summary>
        public int Age { get; set; }

        /// <summary>
        /// Designation of the employedd
        /// </summary>
        public string Designation { get; set; }

        /// <summary>
        /// BasicPay of the employedd
        /// </summary>
        public double BasicPay { get; set; }

        /// <summary>
        /// BasicPay of the employedd
        /// </summary>
        public double Salary { get; set; }

        /// <summary>
        /// Type of the employee - Permanent/Temporary
        /// </summary>
        public string Type { get; set; }
    }
}
