﻿namespace HRManagementAPI.Enums
{
    /// <summary>
    /// EmployeeType
    /// </summary>
    public enum EmployeeType
    {
        Permanent,
        Temporary
    }
}
