using HRManagementAPI.Constants;
using HRManagementAPI.Controllers;
using HRManagementAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Xunit;

namespace HRManagementAPI.UnitTests
{
    public class EmployeeControllerTests
    {
        EmployeeData employeeData;
        EmployeeController employeeController;

        public EmployeeControllerTests()
        {
            employeeData = new EmployeeData();
            employeeController = new EmployeeController(employeeData);
        }

        [Fact]
        public void Verify_GetById_WithEmptyId()
        {
            // Arrange
            string id = "";

            // Act
            var response = employeeController.Get(id);

            var responseResult = (ObjectResult)response;

            // Assert
            Assert.Equal(400, responseResult.StatusCode);
            Assert.Equal(Common.IdNotEmpty, responseResult.Value);
        }
    }
}
