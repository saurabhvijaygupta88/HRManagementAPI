# HRManagementAPI
A .net core api with swagger working
